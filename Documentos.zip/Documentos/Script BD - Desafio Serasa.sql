drop database desafioSerasa;
create database desafioSerasa;
use desafioSerasa;

-- Table: Debito
CREATE TABLE Debito (
    cd_debito int NOT NULL AUTO_INCREMENT,
    dt_debito date NOT NULL,
    cd_empresa int NOT NULL,
    CONSTRAINT Debito_pk PRIMARY KEY (cd_debito)
);

-- Table: Empresa
CREATE TABLE Empresa (
    cd_empresa int NOT NULL AUTO_INCREMENT,
    nm_empresa varchar(100) NOT NULL,
    indice float NOT NULL,
    dt_cadastro date NOT NULL,
    fl_tipo_cadastro int NOT NULL,
    CONSTRAINT Empresa_pk PRIMARY KEY (cd_empresa)
);

-- Table: Nota_Fiscal
CREATE TABLE Nota_Fiscal (
    cd_nota int NOT NULL AUTO_INCREMENT,
    dt_nota_fiscal date NOT NULL,
    cd_empresa int NOT NULL,
    CONSTRAINT Nota_Fiscal_pk PRIMARY KEY (cd_nota)
);

-- foreign keys
-- Reference: Debito_Empresa (table: Debito)
ALTER TABLE Debito ADD CONSTRAINT Debito_Empresa FOREIGN KEY Debito_Empresa (cd_empresa)
    REFERENCES Empresa (cd_empresa);

-- Reference: Nota_Fiscal_Empresa (table: Nota_Fiscal)
ALTER TABLE Nota_Fiscal ADD CONSTRAINT Nota_Fiscal_Empresa FOREIGN KEY Nota_Fiscal_Empresa (cd_empresa)
    REFERENCES Empresa (cd_empresa);
    
--

-- Inserindo dados na tabela `empresa`
INSERT INTO `empresa` (`cd_empresa`, `nm_empresa`, `indice`, `dt_cadastro`, `fl_tipo_cadastro`) VALUES
(1, 'Empresa 1', 55.968, '2020-06-15', 1),
(2, 'Empresa 2', 32.3861, '2020-06-15', 1),
(3, 'Empresa 3', 52.8, '2020-06-15', 1),
(4, 'Empresa 4', 59.1391, '2020-06-15', 1),
(5, 'Empresa 5', 57.7843, '2020-06-15', 1),
(6, 'Empresa 6', 55.968, '2020-06-15', 1),
(7, 'Empresa A', 45.0844, '2020-06-15', 0);

-- Inserindo dados na tabela `debito`
INSERT INTO `debito` (`cd_debito`, `dt_debito`, `cd_empresa`) VALUES
(1, '2020-06-15', 4),
(2, '2020-06-15', 4),
(3, '2020-06-15', 2),
(4, '2020-06-15', 6),
(5, '2020-06-15', 5),
(6, '2020-06-15', 1),
(7, '2020-06-15', 2),
(8, '2020-06-15', 2),
(9, '2020-06-15', 2),
(10, '2020-06-15', 2),
(11, '2020-06-15', 2),
(12, '2020-06-15', 2),
(13, '2020-06-15', 3),
(14, '2020-06-15', 4),
(15, '2020-06-15', 5),
(16, '2020-06-15', 7),
(17, '2020-06-15', 7),
(18, '2020-06-15', 7),
(19, '2020-06-15', 7),
(20, '2020-06-15', 7),
(21, '2020-06-15', 7),
(22, '2020-06-15', 7),
(23, '2020-06-15', 7),
(24, '2020-06-15', 2),
(25, '2020-06-15', 2),
(26, '2020-06-15', 2),
(27, '2020-06-15', 2),
(28, '2020-06-15', 2),
(29, '2020-06-15', 2);

-- Inserindo dados na tabela `nota_fiscal`
INSERT INTO `nota_fiscal` (`cd_nota`, `dt_nota_fiscal`, `cd_empresa`) VALUES
(1, '2020-06-15', 4),
(2, '2020-06-15', 4),
(3, '2020-06-15', 4),
(4, '2020-06-15', 4),
(5, '2020-06-15', 4),
(6, '2020-06-15', 4),
(7, '2020-06-15', 4),
(8, '2020-06-15', 4),
(9, '2020-06-15', 4),
(10, '2020-06-15', 4),
(11, '2020-06-15', 4),
(12, '2020-06-15', 4),
(13, '2020-06-15', 2),
(14, '2020-06-15', 2),
(15, '2020-06-15', 2),
(16, '2020-06-15', 2),
(17, '2020-06-15', 6),
(18, '2020-06-15', 6),
(19, '2020-06-15', 6),
(20, '2020-06-15', 5),
(21, '2020-06-15', 5),
(22, '2020-06-15', 5),
(23, '2020-06-15', 5),
(24, '2020-06-15', 5),
(25, '2020-06-15', 1),
(26, '2020-06-15', 1),
(27, '2020-06-15', 1),
(28, '2020-06-15', 2),
(29, '2020-06-15', 2),
(30, '2020-06-15', 3),
(31, '2020-06-15', 3),
(32, '2020-06-15', 3),
(33, '2020-06-15', 3),
(34, '2020-06-15', 3),
(35, '2020-06-15', 4),
(36, '2020-06-15', 4),
(37, '2020-06-15', 4),
(38, '2020-06-15', 4),
(39, '2020-06-15', 5),
(40, '2020-06-15', 5),
(41, '2020-06-15', 5),
(42, '2020-06-15', 5),
(43, '2020-06-15', 5),
(44, '2020-06-15', 5),
(45, '2020-06-15', 5),
(46, '2020-06-15', 7),
(47, '2020-06-15', 7),
(48, '2020-06-15', 7),
(49, '2020-06-15', 7),
(50, '2020-06-15', 7),
(51, '2020-06-15', 7),
(52, '2020-06-15', 7),
(53, '2020-06-15', 7),
(54, '2020-06-15', 7),
(55, '2020-06-15', 7),
(56, '2020-06-15', 7),
(57, '2020-06-15', 7),
(58, '2020-06-15', 7),
(59, '2020-06-15', 7),
(60, '2020-06-15', 6),
(61, '2020-06-15', 6),
(62, '2020-06-15', 6),
(63, '2020-06-15', 6),
(64, '2020-06-15', 6),
(65, '2020-06-15', 1),
(66, '2020-06-15', 1),
(67, '2020-06-15', 1),
(68, '2020-06-15', 1),
(69, '2020-06-15', 1),
(70, '2020-06-15', 2),
(71, '2020-06-15', 2);